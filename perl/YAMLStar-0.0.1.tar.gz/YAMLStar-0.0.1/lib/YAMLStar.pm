package YAMLStar;

our $VERSION = '0.0.1';
